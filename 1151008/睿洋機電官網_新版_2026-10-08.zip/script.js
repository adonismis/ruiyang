(() => {
  'use strict';
  const menuButton = document.querySelector('[data-menu-toggle]');
  const nav = document.querySelector('[data-nav]');
  const mobile = window.matchMedia('(max-width: 1000px)');
  const setMenu = (open) => {
    menuButton?.setAttribute('aria-expanded', String(open));
    menuButton?.setAttribute('aria-label', open ? '關閉選單' : '開啟選單');
    nav?.classList.toggle('is-open', open);
    document.body.classList.toggle('menu-open', open && mobile.matches);
  };
  menuButton?.addEventListener('click', () => setMenu(menuButton.getAttribute('aria-expanded') !== 'true'));
  nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMenu(false)));
  const closeSubmenus = () => document.querySelectorAll('.submenu-toggle').forEach(button => {
    button.setAttribute('aria-expanded', 'false');
    button.closest('.nav-group')?.classList.remove('open');
  });
  document.querySelectorAll('.submenu-toggle').forEach(button => {
    button.addEventListener('click', () => {
      const open = button.getAttribute('aria-expanded') !== 'true';
      closeSubmenus();
      button.setAttribute('aria-expanded', String(open));
      button.closest('.nav-group')?.classList.toggle('open', open);
    });
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      const wasOpen = menuButton?.getAttribute('aria-expanded') === 'true';
      setMenu(false);
      closeSubmenus();
      if (wasOpen) menuButton.focus();
    }
  });
  mobile.addEventListener('change', () => { setMenu(false); closeSubmenus(); });
  document.addEventListener('click', event => {
    if (!event.target.closest('.nav-group')) closeSubmenus();
  });

  const slides = Array.from(document.querySelectorAll('[data-slide]'));
  let activeSlide = 0;
  const changeSlide = (step) => {
    if (!slides.length) return;
    activeSlide = (activeSlide + step + slides.length) % slides.length;
    slides.forEach((slide, index) => { slide.hidden = index !== activeSlide; });
    const counter = document.querySelector('[data-slide-counter]');
    if (counter) counter.textContent = String(activeSlide + 1).padStart(2, '0') + ' / ' + String(slides.length).padStart(2, '0');
  };
  document.querySelector('[data-slide-prev]')?.addEventListener('click', () => changeSlide(-1));
  document.querySelector('[data-slide-next]')?.addEventListener('click', () => changeSlide(1));

  let toastTimer;
  const notify = (message) => {
    const toast = document.querySelector('[data-toast]');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('visible');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('visible'), 5000);
  };
  document.querySelectorAll('[data-copy]').forEach(button => {
    button.addEventListener('click', async () => {
      const address = button.dataset.copy;
      const status = document.querySelector('[data-copy-status]');
      try {
        if (!navigator.clipboard) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(address);
        if (status) status.textContent = '已複製：' + address;
        notify('地址已複製');
      } catch {
        if (status) status.textContent = '請手動複製地址：' + address;
        notify('瀏覽器未允許複製，請選取頁面上的地址手動複製。');
      }
    });
  });

  document.querySelectorAll('[data-news-filter]').forEach(button => {
    button.addEventListener('click', () => {
      document.querySelectorAll('[data-news-filter]').forEach(item => {
        const active = item === button;
        item.classList.toggle('active', active);
        item.setAttribute('aria-pressed', String(active));
      });
      const heading = document.querySelector('[data-news-heading]');
      if (heading) heading.textContent = button.dataset.newsFilter === '所有消息'
        ? '最新消息，敬請期待' : '目前尚無' + button.dataset.newsFilter;
    });
  });

  const form = document.querySelector('[data-contact-form]');
  if (form) {
    const service = new URLSearchParams(window.location.search).get('service');
    const category = form.elements.namedItem('type');
    if (category && Array.from(category.options).some(option => option.value === service)) category.value = service;
    form.addEventListener('submit', event => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const fields = new FormData(form);
      const categoryText = category.options[category.selectedIndex].text;
      const lines = [
        '睿洋機電工程有限公司｜工程諮詢需求單',
        '建立日期：' + new Date().toLocaleString('zh-TW'),
        '',
        '姓名：' + fields.get('name'),
        '聯絡電話：' + fields.get('phone'),
        '公司名稱：' + (fields.get('company') || '未填寫'),
        '電子信箱：' + (fields.get('email') || '未填寫'),
        '服務類別：' + categoryText,
        '工程地點：' + (fields.get('location') || '未填寫'),
        '',
        '需求說明：',
        fields.get('message'),
        '',
        '此檔案僅儲存於您的裝置，尚未傳送至睿洋機電。'
      ];
      const blob = new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = '睿洋機電_工程諮詢需求單.txt';
      document.body.append(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      const status = document.querySelector('[data-form-status]');
      if (status) status.textContent = '需求單已產生，請確認瀏覽器下載。此資料尚未傳送至公司，請保留檔案以便後續聯繫。';
    });
  }
  document.querySelectorAll('[data-year]').forEach(element => { element.textContent = String(new Date().getFullYear()); });
})();
