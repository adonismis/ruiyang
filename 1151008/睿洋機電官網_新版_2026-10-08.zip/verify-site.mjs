import fs from 'node:fs';
const pages = fs.readdirSync('.').filter(file => file.endsWith('.html'));
const errors = [];
for (const file of pages) {
  const html = fs.readFileSync(file, 'utf8');
  if (!html.includes('assets/logo.jpeg')) errors.push(`${file}: missing supplied logo`);
  if ((html.match(/<h1[ >]/g) || []).length !== 1) errors.push(`${file}: expected one h1`);
  for (const match of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const link = match[1];
    if (/^(https?:|mailto:|tel:|data:)/.test(link)) continue;
    let [path, hash] = link.split('#');
    path = path.split('?')[0] || file;
    if (!fs.existsSync(path)) { errors.push(`${file}: missing ${link}`); continue; }
    if (hash && path.endsWith('.html') && !fs.readFileSync(path, 'utf8').includes(`id="${hash}"`)) errors.push(`${file}: missing anchor ${link}`);
  }
}
console.log(JSON.stringify({ pages: pages.length, errors }, null, 2));
process.exitCode = errors.length ? 1 : 0;
